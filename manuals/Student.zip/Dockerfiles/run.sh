#!/bin/bash
./<exec_name> < $1
